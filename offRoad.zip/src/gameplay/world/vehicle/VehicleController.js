import * as THREE from 'three/webgpu'
import * as RAPIER from '@dimforge/rapier3d-compat'
import Game from '../../../core/Game.js'

class VehicleController {
  constructor(chassis, wheels) {
    this.game = new Game()
    this.physics = this.game.physics
    this.inputs = this.game.inputs
  

    this.chassis = chassis
    this.wheels = wheels

    // constructor
    this.maxForwardSpeed = 15.0   
    this.maxReverseSpeed = 6.0  
    this.speedLimitBrake = 100.0 // torque de freno suave para reducir si ya superaste el límite

    this.isOutsideLimit = false

    this.controller = this.physics.world.createVehicleController(chassis.body)

    // parámetros de rueda
    const suspensionDir = new RAPIER.Vector3(0, -1, 0)
    const axle = new RAPIER.Vector3(0, 0, -1)
    const radius = 0.35

    wheels.forEach((wheel) => {
      const pos = wheel.position
      this.controller.addWheel(
        new RAPIER.Vector3(pos.x, pos.y, pos.z),
        suspensionDir,
        axle,
        0.35, // 0.125
        radius
      )
    })

    wheels.forEach((_, i) => {
      this.controller.setWheelSuspensionRestLength(i, 0.7);
      this.controller.setWheelMaxSuspensionTravel(i, 0.6);
      this.controller.setWheelSuspensionStiffness(i, 65); // N/m aproximado 55
      this.controller.setWheelSuspensionCompression(i, 3.0); // 4
      this.controller.setWheelSuspensionRelaxation(i, 3.0); // 2
      this.controller.setWheelMaxSuspensionForce(i, 20000); // 20000
    })

    // Fricción 
    this.controller.setWheelFrictionSlip(0, 4.5)  
    this.controller.setWheelFrictionSlip(1, 4.5)   
    this.controller.setWheelFrictionSlip(2, 3.5)   
    this.controller.setWheelFrictionSlip(3, 3.5)            // tracción normal
    this.controller.setWheelSideFrictionStiffness(0, 1.2)  // agarre lateral medio
    this.controller.setWheelSideFrictionStiffness(1, 1.2)  
    this.controller.setWheelSideFrictionStiffness(2, 0.85)  
    this.controller.setWheelSideFrictionStiffness(3, 0.85)  

    // parámetros de control
    this.accelerateForce = 50 // 25.0
    this.brakeForce = 25.0
    this.steerAngleMax = Math.PI / 6
  }

  update(dt) {
    if (!this.controller) return

    //console.log(this.isEditing)

    // ---------- inputs ----------
    const fwd = !!this.inputs.keys['forward']
    const back = !!this.inputs.keys['backward']
    const left = !!this.inputs.keys['left']
    const right = !!this.inputs.keys['right']
    const brk = !!this.inputs.keys['brake'] || this.isOutsideLimit

    const throttle = Number(fwd) - Number(back) // 1, 0 ó -1
    const wantBrake = brk

    // Si estamos en modo edición, anular todo el input
    const effectiveThrottle = this.isEditing ? 0 : throttle
    const effectiveBrake =  this.isEditing ? true : wantBrake
    const effectiveSteer =  this.isEditing ? 0 : (Number(left) - Number(right))

    // ---------- obtener velocidad en mundo ----------
    const lin = this.chassis.body.linvel()
    const vel = new THREE.Vector3(lin.x, lin.y, lin.z)

    // ---------- calcular vector "forward" del chasis (usando rotación del cuerpo) ----------
    const r = this.chassis.body.rotation() // {x,y,z,w}
    const chassisQuat = new THREE.Quaternion(r.x, r.y, r.z, r.w)
    // Asumimos que el eje local X del modelo es "adelante". Si tu modelo usa -X, usa ( -1,0,0 ).
    const localForward = new THREE.Vector3(-1, 0, 0)
    const forwardVec = localForward.applyQuaternion(chassisQuat).normalize()
    // velocidad a lo largo del forwardVec: positiva = en sentido "forwardVec"
    const forwardSpeed =  vel.dot(forwardVec) // en m/s (puede ser negativo dependiendo convención)

    // ---------- límites: comprobar si intentan acelerar más allá ----------
    // determinamos la intención de conducción: cuando throttle != 0 indica dirección deseada
    const desiredDir = Math.sign(effectiveThrottle) // 1 => adelante, -1 => atrás, 0 => sin throttle
    // flags que indican si ya estamos por encima del limite en esa dirección
    const overForwardLimit = forwardSpeed > this.maxForwardSpeed
    const overReverseLimit = forwardSpeed < -this.maxReverseSpeed // note: reverse speed is negative along forwardVec

    // ---------- motor: calcular engineTarget (sin aplicarlo todavía) ----------
    let engineTarget = 0
    if (effectiveThrottle !== 0 && !wantBrake) {
      // Si están pidiendo acelerar:
      // - si quieren ir adelante y ya pasaron el limite -> no dar más motor
      if (desiredDir > 0 && overForwardLimit) {
        engineTarget = 0
      // - si quieren ir atrás y ya pasaron limite reverse -> no dar más motor
      } else if (desiredDir < 0 && overReverseLimit) {
        engineTarget = 0
      } else {
        engineTarget = effectiveThrottle * this.accelerateForce;
      }
    } else {
      // sin throttle o freno: desaceleración natural (freno motor suave) pero solo si velocidad apreciable
      const eps = 0.005
      if (Math.abs(forwardSpeed) > eps) {
        // desacelera proporcionalmente a la velocidad actual (constante de damping)
        engineTarget = -forwardSpeed * 5.0
      } else {
        engineTarget = 0
      }
    }

    // suavizado del motor
    this.currentForce = this.currentForce ?? 0
    const smoothFactor = 10
    this.currentForce = THREE.MathUtils.lerp(this.currentForce, engineTarget, 1 - Math.exp(-smoothFactor * dt))

    this.chassis.body.wakeUp()

    // ---------- direccion ----------
   // const steerDir = Number(left) - Number(right)
    const currentSteer = this.controller.wheelSteering(0) || 0
    const targetSteer = this.steerAngleMax * effectiveSteer
    
    let lerpFactor = 0.08
    if (effectiveSteer === 0) lerpFactor = 0.04

    const smoothSteer = THREE.MathUtils.lerp(currentSteer, targetSteer, lerpFactor)
    this.controller.setWheelSteering(0, smoothSteer)
    this.controller.setWheelSteering(1, smoothSteer)

    // ---------- freno (traseras) ----------
    // freno habitual (trasero derrapante)
    let brakeFactor = wantBrake ? 1 : 0
    // reducir freno si vamos marcha atrás (según forwardSpeed signo)
    if (forwardSpeed < -0.01) brakeFactor *= 0.08 // ajusta según sensación

    // const rearBrakeTorque = this.brakeForce * brakeFactor
    // console.log(rearBrakeTorque)

    // fricción y aplicar freno trasero
    this.currentBrake = this.currentBrake ?? 0
    const targetBrake = wantBrake ? this.brakeForce * brakeFactor : 0
    const brakeSmooth = forwardSpeed < -0.01 ?  5 : 0.1 
    this.currentBrake = THREE.MathUtils.lerp(this.currentBrake, targetBrake, 1 - Math.exp(-brakeSmooth * dt))

    this.controller.setWheelBrake(2, this.currentBrake)
    this.controller.setWheelBrake(3, this.currentBrake)


    // ---------- APLICAR LÍMITES ACTIVOS: si ya excedimos límites, ayudar a reducir ---------
    // Si estamos por encima del límite hacia adelante/atrás y no hay throttle en sentido contrario,
    // aplicamos un freno suave sobre las ruedas motrices para bajar la velocidad gradualmente.
    if (!wantBrake) {
      if (overForwardLimit && forwardSpeed > 0) {
        // sobre limite adelante: aplicar freno suave para reducir velocidad
        this.controller.setWheelBrake(2, Math.max(this.controller.wheelBrake(2) || 0, this.speedLimitBrake))
        this.controller.setWheelBrake(3, Math.max(this.controller.wheelBrake(3) || 0, this.speedLimitBrake))
      //  console.log('ok 1')
      } else if (overReverseLimit && forwardSpeed < 0) {
        // sobre limite marcha atrás
        this.controller.setWheelBrake(2, Math.max(this.controller.wheelBrake(2) || 0, this.speedLimitBrake * 0.5))
        this.controller.setWheelBrake(3, Math.max(this.controller.wheelBrake(3) || 0, this.speedLimitBrake * 0.5))
       // console.log('ok 2')
      }
    }

    // ---------- APLICAR engineForce FINAL (siempre al final para evitar re-aplicaciones) ----------
    // Si frenas, motor 0; si no, aplicamos this.currentForce (que respetó el límite más arriba).
    if (effectiveBrake) {
      this.controller.setWheelEngineForce(2, 0)
      this.controller.setWheelEngineForce(3, 0)
      this.currentForce = 0;
    } else {
      this.controller.setWheelEngineForce(2, this.currentForce)
      this.controller.setWheelEngineForce(3, this.currentForce)
    }

    // ---------- avanzar la simulación ----------
    this.controller.updateVehicle(dt)

    // ---------- DEBUG (opcional) ----------
      // if (this.debugCounter === undefined) this.debugCounter = 0
      // if ((this.debugCounter++ % 30) === 0) {
      //   console.log(
      //    `fwdSpeed=${forwardSpeed.toFixed(2)}m/s  maxF=${this.maxForwardSpeed}  maxR=${this.maxReverseSpeed}  engine=${this.currentForce.toFixed(1)}  rearBrake=${rearBrakeTorque.toFixed(1)}`
      //   );
      // }
  }

  syncMeshes() {
    // chasis
     const t = this.chassis.body.translation()
     const r = this.chassis.body.rotation()
     this.chassis.mesh.position.copy(new THREE.Vector3(t.x, t.y, t.z))
     this.chassis.mesh.quaternion.copy(new THREE.Quaternion(r.x, r.y, r.z, r.w))

    // ruedas
     this.wheels.forEach((wheel, i) => {
      wheel.update(this.controller, i)
    })
   }

   get isEditing() {
    return this.game.world?.isEditing === true;
  }

}

export default VehicleController
